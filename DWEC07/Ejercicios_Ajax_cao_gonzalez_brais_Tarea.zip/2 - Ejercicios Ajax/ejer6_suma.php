<?php 
$resultado = $_POST['num1'] + $_POST['num2']; 
echo $resultado;
?>